module.exports = {
  CreateArticle: require('./addarticle'),
  UpdateArticle: require('./updatearticle'),
  DeleteArticle: require('./deletearticle'),
  GetArticleByID: require('./getarticlebyid'),
  GetArticles: require('./getarticles')
};
